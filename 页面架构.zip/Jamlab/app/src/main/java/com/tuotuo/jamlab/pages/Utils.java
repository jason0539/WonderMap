package com.tuotuo.jamlab.pages;

/**
 * Created by liuzhenhui on 2016/10/27.
 */
public class Utils {
    public static final String TAG = Utils.class.getSimpleName();

}
