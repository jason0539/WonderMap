package com.tuotuo.jamlab.pages.fragments.base;

import com.tuotuo.jamlab.R;

/**
 * Created by liuzhenhui on 2016/10/27.
 */
public class TestFragment extends ContentFragment {
    public static final String TAG = TestFragment.class.getSimpleName();

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_test;
    }

    @Override
    protected void onInitView() {

    }
}
