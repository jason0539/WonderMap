package com.tuotuo.jamlab.pages.helper;

/**
 * Created by liuzhenhui on 2016/10/27.
 */
public class LaunchHelper {
    public static final String TAG = LaunchHelper.class.getSimpleName();

    public void checkExit() {

    }
}
